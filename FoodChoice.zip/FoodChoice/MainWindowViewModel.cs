﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FoodChoice
{
    class MainWindowViewModel
    {
        public string M1 { get; set; }
        public string M2 { get; set; }
        public string M3 { get; set; }
        public string M4 { get; set; }
        public Command ShowMsg { get; set; }
        public MainWindowViewModel()
        {
            ShowMsg = new Command(Execute, CanExecute);
        }
        public int MenuNum { get; set; }
        public string Menu { get; set; }
        private bool CanExecute(object arg)
        {
            return true;
        }

        private void Execute(object obj)
        {
            Random rand = new Random();
            MenuNum = rand.Next(1, 5); //난수 1~4
            switch (MenuNum)
            {
                case 1:
                    Menu = M1;
                    break;
                case 2:
                    Menu = M2;
                    break;
                case 3:
                    Menu = M3;
                    break;
                case 4:
                    Menu = M4;
                    break;
            }
            MessageBox.Show(Menu);
        }
    }

}
