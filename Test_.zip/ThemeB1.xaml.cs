﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test_
{
    /// <summary>
    /// ThemeB1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ThemeB1 : Page
    {
        public ThemeB1()
        {
            InitializeComponent();
            string[] Names = { "낙지볶음", "닭갈비", "등갈비김치찜", "새우계란볶음밥", "샤브샤브", "수제비", "우동", "제육볶음", "쭈꾸미" };
            Image[] Images = { img1, img2, img3, img4, img5, img6, img7, img8, img9 };
            TextBlock[] texts = { TextBox1, TextBox2, TextBox3, TextBox4, TextBox5, TextBox6, TextBox7, TextBox8, TextBox9 };
            for (int i = 0; i < Names.Length; i++)
            {
                Images[i].Source = new BitmapImage(new Uri(@"C:\Users\황지호\source\repos\Test_\Test_\Resources" + Names[i] + ".jpg", UriKind.RelativeOrAbsolute));
                texts[i].Text = Names[i];
            }
        }
    }
}
