﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Food
{
    class FoodsList
    {
        public IEnumerable<Food> GetAllFoods()
        {
            return foods;
        }

        public IEnumerable<Food> FindFoods(string searchString)
        {
            return foods.Where(p => p.Title.Contains(searchString));
        }


        static IList<Food> foods;
        static FoodsList()
        {
            foods = new List<Food>();
            foods.Add(new Food()
            {
                Title = "족발",
                Price = 40000,
                Source = "/Resources/족발.jpg"
            });
            foods.Add(new Food()
            {
                Title = "양념족발",
                Price = 40000,
                Source = "/Resources/양념족발.jpg"
            });
            foods.Add(new Food()
            {
                Title = "냉채족발",
                Price = 40000,
                Source = "/Resources/냉채족발.jpg"
            });
            foods.Add(new Food()
            {
                Title = "마늘족발",
                Price = 43000,
                Source = "/Resources/마늘족발.jpg"
            });
            foods.Add(new Food()
            {
                Title = "보쌈",
                Price = 40000,
                Source = "/Resources/보쌈.jpg"
            });
            foods.Add(new Food()
            {
                Title = "딸기빙수",
                Price = 14500,
                Source = "/Resources/딸기빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "망고빙수",
                Price = 13900,
                Source = "/Resources/망고빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "티라미수빙수",
                Price = 11900,
                Source = "/Resources/티라미수빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "민트초코빙수",
                Price = 11900,
                Source = "/Resources/민트초코빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "그린티빙수",
                Price = 11500,
                Source = "/Resources/그린티빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치즈빙수",
                Price = 10900,
                Source = "/Resources/치즈빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "인절미빙수",
                Price = 8900,
                Source = "/Resources/인절미빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "흑임자빙수",
                Price = 11900,
                Source = "/Resources/흑임자빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "오레오빙수",
                Price = 11900,
                Source = "/Resources/오레오빙수.jpg"
            });
            foods.Add(new Food()
            {
                Title = "연어샐러드",
                Price = 10500,
                Source = "/Resources/연어샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "리코타치즈샐러드",
                Price = 9500,
                Source = "/Resources/리코타치즈샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "새우샐러드",
                Price = 10500,
                Source = "/Resources/새우샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "닭가슴살샐러드",
                Price = 10000,
                Source = "/Resources/닭가슴살샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "불고기샐러드",
                Price = 12500,
                Source = "/Resources/불고기샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "버섯샐러드",
                Price = 9500,
                Source = "/Resources/버섯샐러드.jpg"
            });
            foods.Add(new Food()
            {
                Title = "베이컨고구마피자",
                Price = 15900,
                Source = "/Resources/베이컨고구마피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "콤비네이션피자",
                Price = 14900,
                Source = "/Resources/콤비네이션피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "포테이토피자",
                Price = 15900,
                Source = "/Resources/포테이토피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "바베큐치킨피자",
                Price = 15900,
                Source = "/Resources/바베큐치킨피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "고구마피자",
                Price = 15900,
                Source = "/Resources/고구마피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "불고기피자",
                Price = 15900,
                Source = "/Resources/불고기피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "페퍼로니피자",
                Price = 14900,
                Source = "/Resources/페퍼로니피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "하와이안피자",
                Price = 14900,
                Source = "/Resources/하와이안피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치즈피자",
                Price = 14900,
                Source = "/Resources/치즈피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "에그콘피자",
                Price = 18900,
                Source = "/Resources/에그콘피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "쉬림프피자",
                Price = 18900,
                Source = "/Resources/쉬림프피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "베이컨고구마피자",
                Price = 15900,
                Source = "/Resources/베이컨고구마피자.jpg"
            });
            foods.Add(new Food()
            {
                Title = "까만찜닭",
                Price = 21000,
                Source = "/Resources/까만찜닭.jpg"
            });
            foods.Add(new Food()
            {
                Title = "빨간찜닭",
                Price = 21000,
                Source = "/Resources/빨간찜닭.jpg"
            });
            foods.Add(new Food()
            {
                Title = "로제찜닭",
                Price = 24000,
                Source = "/Resources/로제찜닭.jpg"
            });
            foods.Add(new Food()
            {
                Title = "감바스떡볶이",
                Price = 13000,
                Source = "/Resources/감바스떡볶이.jpg"
            });
            foods.Add(new Food()
            {
                Title = "로제떡볶이",
                Price = 12000,
                Source = "/Resources/로제떡볶이2.jpg"
            });
            foods.Add(new Food()
            {
                Title = "빨간떡볶이",
                Price = 10000,
                Source = "/Resources/빨간떡볶이.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치즈떡볶이",
                Price = 12000,
                Source = "/Resources/치즈떡볶이.jpg"
            });
            foods.Add(new Food()
            {
                Title = "야채죽",
                Price = 7400,
                Source = "/Resources/야채죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "단호박죽",
                Price = 7400,
                Source = "/Resources/단호박죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "팥죽",
                Price = 7400,
                Source = "/Resources/팥죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "참치죽",
                Price = 8400,
                Source = "/Resources/참치죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "낙지김치죽",
                Price = 8900,
                Source = "/Resources/낙지김치죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "소고기죽",
                Price = 7900,
                Source = "/Resources/소고기죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "전복죽",
                Price = 9900,
                Source = "/Resources/전복죽.jpg"
            });
            foods.Add(new Food()
            {
                Title = "나물비빔밥",
                Price = 8000,
                Source = "/Resources/나물비빔밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "불고기비빔밥",
                Price = 9500,
                Source = "/Resources/불고기비빔밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "낙지비빔밥",
                Price = 9500,
                Source = "/Resources/낙지비빔밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "김밥",
                Price = 3900,
                Source = "/Resources/김밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "불고기김밥",
                Price = 5500,
                Source = "/Resources/불고기김밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "새우튀김김밥",
                Price = 5000,
                Source = "/Resources/새우튀김김밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "참치김밥",
                Price = 4900,
                Source = "/Resources/참치김밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "돈가스김밥",
                Price = 5000,
                Source = "/Resources/돈가스김밥.jpg"
            });
            foods.Add(new Food()
            {
                Title = "후라이드치킨",
                Price = 18000,
                Source = "/Resources/후라이드치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "양념치킨",
                Price = 19500,
                Source = "/Resources/양념치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "간장치킨",
                Price = 18900,
                Source = "/Resources/간장치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "어니언치킨",
                Price = 19000,
                Source = "/Resources/어니언치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "갈릭치킨",
                Price = 19000,
                Source = "/Resources/갈릭치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "파닭치킨",
                Price = 19000,
                Source = "/Resources/파닭치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치즈치킨",
                Price = 19000,
                Source = "/Resources/치즈치킨.jpg"
            });
            foods.Add(new Food()
            {
                Title = "마라파스타",
                Price = 10900,
                Source = "/Resources/마라파스타.jpg"
            });
            foods.Add(new Food()
            {
                Title = "까르보나라파스타",
                Price = 9500,
                Source = "/Resources/까르보나라파스타.jpg"
            });
            foods.Add(new Food()
            {
                Title = "토마토파스타",
                Price = 9500,
                Source = "/Resources/토마토파스타.jpg"
            });
            foods.Add(new Food()
            {
                Title = "로제파스타",
                Price = 9500,
                Source = "/Resources/로제파스타.jpg"
            });
            foods.Add(new Food()
            {
                Title = "알리오올리오파스타",
                Price = 9000,
                Source = "/Resources/알리오올리오파스타.jpg"
            });
            foods.Add(new Food()
            {
                Title = "마라탕",
                Price = 8000,
                Source = "/Resources/마라탕2.jpg"
            });
            foods.Add(new Food()
            {
                Title = "마라샹궈",
                Price = 15000,
                Source = "/Resources/마라샹궈2.jpg"
            });
            foods.Add(new Food()
            {
                Title = "꿔바로우",
                Price = 12000,
                Source = "/Resources/꿔바로우2.jpg"
            });
            foods.Add(new Food()
            {
                Title = "짜장면",
                Price = 6000,
                Source = "/Resources/짜장면.jpg"
            });
            foods.Add(new Food()
            {
                Title = "삼선짜장",
                Price = 8500,
                Source = "/Resources/삼선짜장.jpg"
            });
            foods.Add(new Food()
            {
                Title = "짬뽕",
                Price = 7000,
                Source = "/Resources/짬뽕.jpg"
            });
            foods.Add(new Food()
            {
                Title = "볶음짬뽕",
                Price = 8000,
                Source = "/Resources/볶음짬뽕.jpg"
            });
            foods.Add(new Food()
            {
                Title = "불고기버거",
                Price = 4100,
                Source = "/Resources/불고기버거.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치즈버거",
                Price = 4800,
                Source = "/Resources/치즈버거.jpg"
            });
            foods.Add(new Food()
            {
                Title = "새우버거",
                Price = 4100,
                Source = "/Resources/새우버거.jpg"
            });
            foods.Add(new Food()
            {
                Title = "치킨버거",
                Price = 3300,
                Source = "/Resources/치킨버거.jpg"
            });
            foods.Add(new Food()
            {
                Title = "김치찌개",
                Price = 8500,
                Source = "/Resources/김치찌개.jpg"
            });
            foods.Add(new Food()
            {
                Title = "부대찌개",
                Price = 8500,
                Source = "/Resources/부대찌개.jpg"
            });
        }



        public class Food : Notifier
        {
            private string title; //음식이름
            public string Title
            {
                get { return title; }
                set
                {
                    title = value;
                    OnPropertyChanged("Title");
                }
            }

            private int price; //음식가격

            public int Price
            {
                get { return price; }
                set
                {
                    price = value;
                    OnPropertyChanged("Price");
                }
            }

            private string source; //음식이미지소스

            public string Source
            {
                get { return source; }
                set
                {
                    source = value;
                    OnPropertyChanged("Source");
                }
            }


        }
    }
}
