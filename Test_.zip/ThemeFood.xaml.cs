﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test_
{
    /// <summary>
    /// ThemeFood.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ThemeFood : Page
    {
        public ThemeFood()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //집밥
        {
            NavigationService.Navigate(new Uri("/ThemeB1.xaml", UriKind.Relative));

        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //데이트
        {
            NavigationService.Navigate(new Uri("/ThemeB2.xaml", UriKind.Relative));

        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //간식
        {
            NavigationService.Navigate(new Uri("/ThemeB3.xaml", UriKind.Relative));


        }

        private void Button_Click_4(object sender, RoutedEventArgs e) //이색음식
        {
            NavigationService.Navigate(new Uri("/ThemeB4.xaml", UriKind.Relative));

        }
    }
}
